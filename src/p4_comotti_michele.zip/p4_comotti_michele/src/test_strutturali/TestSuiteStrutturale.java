package test_strutturali;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ AggiuntaCredenzialiStrutturale.class, ModificaCredenzialiStrutturali.class,
		NormalizzazioneTestStrutturale.class })
public class TestSuiteStrutturale {

}
