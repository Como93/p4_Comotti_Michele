package p4_comotti_michele_usecase1_11_14;
/**
 * Classe per definire l'oggetto Credenziali
 */
public class Credenziali{
    /** Attributi */
    private String username;
    private String password;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}