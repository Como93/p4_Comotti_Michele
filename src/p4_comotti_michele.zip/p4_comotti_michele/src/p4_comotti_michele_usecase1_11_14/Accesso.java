package p4_comotti_michele_usecase1_11_14;



import java.util.Scanner;

/**
 * Classe per implementare la funzione Accesso negli AppStore supportati
 */
public class Accesso implements Visitor{ 
    private Credenziali server;
	/**
     * Funzione visit del Visitor per il GoogleStore
     *
     */
	
    // costruttore Accesso serve per confrontare le credenziali scaricate dal server con quelle che poi verranno immesse dall'utente
	public Accesso(Credenziali server){
		this.server = server;
	}
	
	// Vengono inserite le credenziali dall'utente e poi viene lanciato l'accesso al Visitor con la funzione accesso che restituisce un booleano
    public void visit(GoogleStore google){
    	 Scanner input = new Scanner(System.in);
    	 Credenziali c = new Credenziali(); 
    	
    	 boolean response = false;
    	 while(response == false){
    		 System.out.println("Inserisci username in Google Store");
             String username = input.nextLine();
             c.setUsername(username);
             System.out.println("Inserisci password in Google Store");
             String password = input.nextLine();
             c.setPassword(password);
             
             response = google.accesso(c,this.server);
             
             if(response == false){
 	        	System.out.println("Vuoi riprovare ad inserire le credenziali? 1 per si 0 per no");
 		        
 		        int riprovo = input.nextInt();
 		        
 		        if(riprovo == 0){
 		        	break;
 		        }
 		       input = new Scanner(System.in);
 	        }
 	        
 	        
    	 }
    	
    	 if(response == true){
    		 google.setCredenzialiGoogle(c);
    	        
    	     System.out.println("Benvenuto " + google.getCredenzialiGoogle().getUsername());
    	 }
        
        
    }
    /**
     * Funzione visit del Visitor per l'AppleStore
     *
     * @param apple AppStore specifico
     */
	// Vengono inserite le credenziali dall'utente e poi viene lanciato l'accesso al Visitor con la funzione accesso che restituisce un booleano

    public void visit(AppleStore apple){
    	 Scanner input = new Scanner(System.in);
    	 Credenziali c = new Credenziali(); 
    	 boolean response = false;
    	 while(response == false){
    		 System.out.println("Inserisci username in Apple Store");
             String username = input.nextLine();
             c.setUsername(username);
             System.out.println("Inserisci password in Apple Store");
             String password = input.nextLine();
             c.setPassword(password);
             
             response = apple.accesso(c,this.server);
             
             if(response == false){
 	        	System.out.println("Vuoi riprovare ad inserire le credenziali? 1 per si 0 per no");
 		        
 		        int riprovo = input.nextInt();
 		        
 		        if(riprovo == 0){
 		        	break;
 		        }
 		        input = new Scanner(System.in);
 	        }
 	        
 	      
    	 }
        
    	 if(response == true){
    		 apple.setCredenzialiApple(c);
    	        
    	     System.out.println("Benvenuto " + apple.getCredenzialiApple().getUsername());
    	 } 
        
        
    }
    /**
     * Funzione visit del Visitor il WinStore
     *
     * @param win AppStore specifico
     */
    
	// Vengono inserite le credenziali dall'utente e poi viene lanciato l'accesso al Visitor con la funzione accesso che restituisce un booleano

    public void visit(WinStore win){
    	Scanner input = new Scanner(System.in);
   	 	Credenziali c = new Credenziali(); 
   	 	boolean response = false;
   	 	while(response == false){
	        System.out.println("Inserisci username in Windows Store");
	        String username = input.nextLine();
	        c.setUsername(username);
	        System.out.println("Inserisci password in Windows Store");
	        String password = input.nextLine();
	        c.setPassword(password);
	        
	        response = win.accesso(c,this.server);
	        
	        if(response == false){
	        	System.out.println("Vuoi riprovare ad inserire le credenziali? 1 per si 0 per no");
		        
		        int riprovo = input.nextInt();
		        
		        if(riprovo == 0){
		        	break;
		        }
		        input = new Scanner(System.in);
	        }
	        
	        
   	 	}
   	 	
   	 	if(response == true){
   	 		win.setCredenzialiWin(c);
   	 	
   	 		System.out.print("Benvenuto " + win.getCredenzialiWin().getUsername());
   	 	}
   	 	
    }
    
}