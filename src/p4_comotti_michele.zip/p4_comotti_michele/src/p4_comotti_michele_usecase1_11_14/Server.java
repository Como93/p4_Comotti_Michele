package p4_comotti_michele_usecase1_11_14;
import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Server {
	
	private static final int PORT = 5252;
	
	//server per estrazione credenziali dei vari app store
	public static void main(String[] args)  {
		try{
			// Definizione oggetto
			EstrazioneCredenziali estr = new EstrazioneCredenzialiImpl();
				
			//Creazione Registro RMI con porta
			Registry registry = LocateRegistry.createRegistry(PORT);
				
				
			//Congiungere l'oggetto
			registry.bind("estrazione", estr);
			
			System.out.println("Estrazione dati running at "+PORT+" port...");
		} catch(RemoteException e){
			e.printStackTrace();
		} catch(AlreadyBoundException e){
			e.printStackTrace();
		}
		
		
		
	}

}
