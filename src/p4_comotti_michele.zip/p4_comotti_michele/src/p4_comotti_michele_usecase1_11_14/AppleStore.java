package p4_comotti_michele_usecase1_11_14;

import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
/**
 * Classe per l'implementazione dell'AppleStore
 */
public class AppleStore implements ElementAppStore{
    /** Attributi */
    private Credenziali credenziali;
   
    
   
    /**
     * Funzione accept del pattern Visitor
     *
     * @param visitor Il Visitor
     */
    public void accept(Visitor visitor){
    	visitor.visit(this);
    }
    /**
     * Funzione per l'estrazione dei dati dall'AppleStore
     *
     * @param app L'App di cui estrarre i dati
     * @return Il file contenente i dati estratti 
     */
    public File estrazioneDati(App app){
 
    	return null;
    }
    /**
     * Funzione per effettuare l'accesso sull'AppleStore
     *
     * @param credenziali Le credenziali per accedere
     * @return true se è andata a buon fine, false se non è andata a buon fine
     */
    public boolean accesso(Credenziali credenziali,Credenziali cred_server){
    	System.out.println("Loading...");
    	try {
			TimeUnit.SECONDS.sleep(3);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	if(credenziali.getUsername().equals(cred_server.getUsername()) && credenziali.getPassword().equals(cred_server.getPassword())){
    		
			return true;
		}
    	
    	return false;
    }
    /**
     * Funzione per ottenere la lista delle App dell'utente presenti sull'AppleStore
     *
     * @return La lista delle App dell'utente presenti sull'AppleStore
     */
    public ArrayList<App> getListaApp(){
    	
    	return null;
    }
	public Credenziali getCredenzialiApple() {
		return credenziali;
	}
	public void setCredenzialiApple(Credenziali credenziali) {
		this.credenziali = credenziali;
	}

}