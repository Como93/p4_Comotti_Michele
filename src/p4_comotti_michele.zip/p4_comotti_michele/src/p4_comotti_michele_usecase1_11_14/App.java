package p4_comotti_michele_usecase1_11_14;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Classe per la definizione di App
 */
public class App{
    /** Attributi */
    private int id;
    private String nomeApp;
    private ElementAppStore store;
    /** Associazioni */
    private Dati dati;
   
    // costruttore App che ha il nome e la provenienza dello store
    public App(String nomeApp,ElementAppStore store) {
		// TODO Auto-generated constructor stub
    	this.nomeApp = nomeApp;
    	this.store = store;
	}
    
    /**
     * Funzione per la visualizzazione dei dati dell'App
     * @throws IOException 
     *
     */
    // visualizza i dati (in questo caso c'è solo la normalizzazione perchè use case sviluppato)
    public void visualizzazioneDati() throws IOException{
    	 
    	 normalizzazioneDati();
    	
    	 
    }
    /**
     * Funzione per l'estrazione dei dati di un'App dal suo AppStore
     *
     * @return true se è andata a buon fine, false se non è andata a buon fine
     */
    public boolean estrazioneDatiApp(){
    	
    	return false;
    }
    /**
     * Funzione per la normalizzazione dei dati di un App
     *
     */
    
    /*NORMALIZZAZIONE DATI: si presuppone che l'estrazione dati sia andata a buon fine e che i dati 
     * estratti vengano salvati in vari file. Questi file vengono inseriti all'interno di un'arraylist che,
     * in base all'app che viene selezionata dall'utente, verrà scorsa. Ovviamente se l'utente ha selezionato
     * un'app ma non ha i suoi file il metodo non normalizzerà nulla. Avviene lo scorrimento dei file in cui vengono
     * presi e ordinati questi dati all'interno di altre arraylist. Dati in comune si cerca di renderli tutti allo
     * stesso tipo*/
    public void normalizzazioneDati() throws IOException{
    	boolean primoCarrier = false;
		boolean primoTablet = false;
		boolean primoVersionCode = false;
		boolean primoVersionOs = false;
		boolean primoCountry = false;
		boolean primoDevice = false;
		boolean primoLanguage = false;
		boolean primoRating = false;
		boolean primoType = false;
		//boolean duplicato;
		String pack = null;
		String name_pack = null;
		String tipo = null;
		Double somma_new = 0.0;
		Double somma_revised = 0.0;
		ArrayList<String> market = new ArrayList<String>();
		ArrayList<String> type = new ArrayList<String>();
		ArrayList<String> date_win = new ArrayList<String>();
		ArrayList<String> rat = new ArrayList<String>();
		ArrayList<Double> average_rating = new ArrayList<Double>();
		ArrayList<Double> count_average = new ArrayList<Double>();
		ArrayList<String> at = new ArrayList<String>();
		ArrayList<String> dat = new ArrayList<String>();
		ArrayList<Double> dai = new ArrayList<Double>();
		ArrayList<Double> tot = new ArrayList<Double>();
		ArrayList<String> car = new ArrayList<String>();
		ArrayList<String> tab = new ArrayList<String>();
		ArrayList<Integer> number_rating = new ArrayList<Integer>();
		ArrayList<String> version_code = new ArrayList<String>();
		ArrayList<String> version_os = new ArrayList<String>();
		ArrayList<String> country = new ArrayList<String>();
		ArrayList<String> device = new ArrayList<String>();
		ArrayList<String> language = new ArrayList<String>();
		ArrayList<String> listaVersion_os = new ArrayList<String>();
		ArrayList<String> listaVersion_code = new ArrayList<String>();
		ArrayList<String> listaCountry = new ArrayList<String>();
		ArrayList<String> listaDevice = new ArrayList<String>();
		ArrayList<String> listaLanguage = new ArrayList<String>();
		ArrayList<String> listaCar = new ArrayList<String>();
		ArrayList<String> listaTab = new ArrayList<String>();
		ArrayList<ArrayList<String>> listaFile = new ArrayList<ArrayList<String>>();
		dati = new Dati();
    	String s = this.store.toString().substring(this.store.toString().indexOf(".")+1, this.store.toString().indexOf("@"));
    	if(s.equals("GoogleStore")){
    		
    		ArrayList<String> filename = new ArrayList<String>();
    		filename.add("src/rating_google/ratings_com.letfreex_201705_app_version.csv");
    		filename.add("src/rating_google/ratings_com.letfreex_201705_carrier.csv");
    		filename.add("src/rating_google/ratings_com.letfreex_201705_country.csv");
    		filename.add("src/rating_google/ratings_com.letfreex_201705_device.csv");
    		filename.add("src/rating_google/ratings_com.letfreex_201705_language.csv");
    		filename.add("src/rating_google/ratings_com.letfreex_201705_os_version.csv");
    		filename.add("src/rating_google/ratings_com.letfreex_201705_overview.csv");
    		filename.add("src/rating_google/ratings_com.letfreex_201705_tablets.csv");
    		
    		for(int i = 0; i < filename.size();i++){
    			if(filename.get(i).substring(0).contains(this.nomeApp) == true){
    				
    				if(i > 0){
    					 dat.clear();
    		 		        dai.clear();
    		 		        tot.clear();
    		 		        at.clear();
    				}

    				String f = filename.get(i);
    				
    				if(filename.get(i).contains("overview")){
    					 	BufferedReader CSVFile = new BufferedReader(new FileReader(f));
    	    		        
    	    		        String dataRow = CSVFile.readLine(); // Read first line;
    	    		        String[] attr = dataRow.split(",");
    	    		        for(int k = 0; k < attr.length;k++){
    	    		        	at.add(attr[k]);
    	    		        }
    	    		        dati.setAttributi(at);
    	    		        
    	    		        
    	    		        dataRow = CSVFile.readLine();
    	    		        
    	    	         	while(dataRow != null){
    	    		        	String[] values = dataRow.split(",");
    	    		        	for(int t = 0;t < values.length;t++){
    	    		        		switch(dati.getAttributi().get(t)){
    		    		        		case "Date":
    		    		        			dat.add(values[t]);
    		    						break;
    		    						case "Package Name":
    		    							 pack = values[t];
    		    						break;
    		    						case "Daily Average Rating":
    		    							if(values[t].equals("NA")){
												dai.add(0.0);
											} else {
												Double dP = Double.parseDouble(values[t]);
												dai.add(dP);
											}
    		    						break;
    		    						case "Total Average Rating":
    		    							if(values[t].equals("NA")){
												tot.add(0.0);
											} else {
												Double to = Double.parseDouble(values[t]);
												tot.add(to);
											}
    		    						break;
    		    						
    	    		        		}
    	    		        	}
    	    		        	dataRow = CSVFile.readLine();
    	    		        }
    	    		        
    	    		        CSVFile.close();
    	    		        
    	    		        dati.setData_overview(dat);
   		        		 	dati.setPackage_name_overview(pack);
   		        		 	dati.setDaily_average_overview(dai);
   		        		 	dati.setTotal_average_overview(tot);
   		        		 	
   		        		 	System.out.println(filename.get(i)+" :");
   		        		 	System.out.println(dati.getPackage_name_overview());
   		        		 	System.out.println(dati.getData_overview());
   		        		 	System.out.println(dati.getDaily_average_overview());
   		        		 	System.out.println(dati.getTotal_average_overview());
   		        		 	System.out.println();
   		        		 	
    	    		        
    				}else{
    					
    					BufferedReader CSVFile = new BufferedReader(new FileReader(f));
        		        
        		        String dataRow = CSVFile.readLine(); // Read first line;
        		        String[] attr = dataRow.split(",");
        		        for(int k = 0; k < attr.length;k++){
        		        	at.add(attr[k]);
        		        }
        		        dati.setAttributi(at);
        		        
        		        
        		        dataRow = CSVFile.readLine();
        		        
        		        while(dataRow != null){
        		        	String[] values = dataRow.split(",");
        		        	
        		        	for(int t = 0;t < values.length;t++){
        		        		switch(dati.getAttributi().get(t)){
    	    		        		case "Carrier":
    	    							if(primoCarrier == false){
    	    								primoCarrier = true;
    	    								listaFile.add(car);
    	    								car.add(values[t]);
    	    							}else{
    	    								boolean duplicato = false;
    	    								for(int c = 0; c < car.size();c++){
    	    									if(car.get(c).equals(values[t]) ){
    	    										duplicato = true;
    	    									}
    	    								}
    	    								if(duplicato == false){
    	    									car.add(values[t]);
    	    								}
    	    							
    	    							}
    	    							
    	    							break;
    	    						case "Tablets":
    	    							if(primoTablet == false){
    	    								primoTablet = true;
    	    								listaFile.add(tab);
    	    								tab.add(values[t]);
    	    							}else{
    	    								boolean duplicato = false;
    	    								for(int c = 0; c < tab.size();c++){
    	    									if(tab.get(c).equals(values[t]) ){
    	    										duplicato = true;
    	    									}
    	    								}
    	    								if(duplicato == false){
    	    									tab.add(values[t]);
    	    								}
    	    								
    	    							}
    	    							
    	    							break;
    	    						case "App Version Code":
    	    							if(primoVersionCode == false){
    	    								primoVersionCode = true;
    	    								listaFile.add(version_code);
    	    								version_code.add(values[t]);
    	    							}else{
    	    								boolean duplicato = false;
    	    								for(int c = 0; c < version_code.size();c++){
    	    									if(version_code.get(c).equals(values[t]) ){
    	    										duplicato = true;
    	    									}
    	    								}
    	    								if(duplicato == false){
    	    									version_code.add(values[t]);
    	    								}
    	    								
    	    							}
    	    							
    	    							break;
    	    						case "Android OS Version":
    	    							if(primoVersionOs == false){
    	    								primoVersionOs = true;
    	    								listaFile.add(version_os);
    	    								version_os.add(values[t]);
    	    							}else{
    	    								boolean duplicato = false;
    	    								for(int c = 0; c < version_os.size();c++){
    	    									if(version_os.get(c).equals(values[t]) ){
    	    										duplicato = true;
    	    									}
    	    								}
    	    								if(duplicato == false){
    	    									version_os.add(values[t]);
    	    								}
    	    								
    	    							}
    	    							
    	    							break;
    	    						case "Country":
    	    							if(primoCountry == false){
    	    								primoCountry = true;
    	    								listaFile.add(country);
    	    								country.add(values[t]);
    	    							}else{
    	    								boolean duplicato = false;
    	    								for(int c = 0; c < country.size();c++){
    	    									if(country.get(c).equals(values[t]) ){
    	    										duplicato = true;
    	    									}
    	    								}
    	    								if(duplicato == false){
    	    									country.add(values[t]);
    	    								}
    	    								
    	    							}
    	    							
    	    							break;
    	    						case "Language":
    	    							if(primoLanguage == false){
    	    								primoLanguage = true;
    	    								listaFile.add(language);
    	    								language.add(values[t]);
    	    							}else{
    	    								boolean duplicato = false;
    	    								for(int c = 0; c < language.size();c++){
    	    									if(language.get(c).equals(values[t]) ){
    	    										duplicato = true;
    	    									}
    	    								}
    	    								if(duplicato == false){
    	    									language.add(values[t]);
    	    								}
    	    								
    	    							}
    	    							
    	    							break;
    	    						case "Device":
    	    							if(primoDevice == false){
    	    								primoDevice = true;
    	    								listaFile.add(device);
    	    								device.add(values[t]);
    	    							}else{
    	    								boolean duplicato = false;
    	    								for(int c = 0; c < device.size();c++){
    	    									if(device.get(c).equals(values[t]) ){
    	    										duplicato = true;
    	    									}
    	    								}
    	    								if(duplicato == false){
    	    									device.add(values[t]);
    	    								}
    	    								
    	    							}
    	    							
    	    							break;
        		        		}
        		        	}
        		        	dataRow = CSVFile.readLine();
        		        }
        		        
        		        CSVFile.close();
        		        
        		        
        		      
        		        for(int r = 0; r < listaFile.get(0).size(); r++){
        	    		    	   File CSVFile1 = new File(f);
        	    		    	   Scanner inputStream1 = new Scanner(CSVFile1);
        	    		    	   inputStream1.nextLine();
        	    		        	
        	    		           while(inputStream1.hasNextLine()){
        	    	    		        	String dataRow1 = inputStream1.nextLine();
        	    	    		        	String[] values1 = dataRow1.split(",");
        	    	    		        	for(int z = 0; z < values1.length; z++){
        	    	    		        		if(listaFile.get(0).get(r).equals(values1[z])){
        	    	    		        			for(int x = 0; x < values1.length; x++){
        	    	    		        				switch(dati.getAttributi().get(x)){
        	    	    		        					case "Date":
        	    	    		        						dat.add(values1[x]);
        	    	    		        					break;
        	    	    		        					case "Package Name":
        	    	    		        						 pack = values1[x];
        	    	    		        					break;
        	    	    		        					case "Android OS Version":
        	    	    		        						listaVersion_os.add(listaFile.get(0).get(r));
        	    	    		        					break;
        	    	    		        					case "App Version Code":
        	    	    		        						listaVersion_code.add(listaFile.get(0).get(r));
        	    	    		        					break;
        	    	    		        					case "Carrier":
        	    	    		        						listaCar.add(listaFile.get(0).get(r));
        	    	    		        					break;
        	    	    		        					case "Country":
        	    	    		        						listaCountry.add(listaFile.get(0).get(r));
        	    	    		        					break;
        	    	    		        					case "Device":
        	    	    		        						listaDevice.add(listaFile.get(0).get(r));
        	    	    		        					break;
        	    	    		        					case "Tablets":
        	    	    		        						listaTab.add(listaFile.get(0).get(r));
        	    	    		        					break;
        	    	    		        					case "Language":
        	    	    		        						listaLanguage.add(listaFile.get(0).get(r));
        	    	    		        					break;
        	    	    		        					case "Daily Average Rating":
        	    	    		        						if(values1[x].equals("NA")){
        	    													dai.add(0.0);
        	    												} else {
        	    													Double dP = Double.parseDouble(values1[x]);
        	    													dai.add(dP);
        	    												}
        	    	    		        					break;
        	    	    		        					case "Total Average Rating":
        	    												if(values1[x].equals("NA")){
        	    													tot.add(0.0);
        	    												} else {
        	    													Double to = Double.parseDouble(values1[x]);
        	    													tot.add(to);
        	    												}
        	    											break;
        	    	    		        				}
        	    	    		        				
        	    	    		        			}
        	    	    		        		}
        	    	    		        	}
        	    	    		        	
        	    		        	 }
        	    		        	 inputStream1.close();
        	    		        }
    					
        		    if(filename.get(i).contains("os_version")){
   		        		 dati.setData_os_version(dat);
   		        		 dati.setPackage_name_os_version(pack);
   		        		 dati.setOs_version(listaVersion_os);
   		        		 dati.setDaily_average_os_version(dai);
   		        		 dati.setTotal_average_os_version(tot);
   		        		 
   		        		 System.out.println(filename.get(i)+" :");
   		        		 System.out.println(dati.getPackage_name_os_version());
   		        		 System.out.println(dati.getData_os_version());
   		        		 System.out.println(dati.getOs_version());
   		        		 System.out.println(dati.getDaily_average_os_version());
   		        		 System.out.println(dati.getTotal_average_os_version());
   		        		 System.out.println();
   		        		
   		        		 
   		        	}
       		        else if(filename.get(i).contains("app_version")){
       		        	 dati.setData_app_version(dat);
   		        		 dati.setPackage_name_app_version(pack);
   		        		 dati.setApp_version(listaVersion_code);
   		        		 dati.setDaily_average_app_version(dai);
   		        		 dati.setTotal_average_app_version(tot);
   		        		
   		        		 System.out.println(filename.get(i)+" :");
   		        		 System.out.println(dati.getPackage_name_app_version());
   		        		 System.out.println(dati.getData_app_version());
   		        		 System.out.println(dati.getApp_version());
   		        		 System.out.println(dati.getDaily_average_app_version());
   		        		 System.out.println(dati.getTotal_average_app_version());
   		        		 System.out.println();
   		        		 
       		        }
       		        else if(filename.get(i).contains("carrier")){
      		        	     dati.setData_carrier(dat);
   		        		 dati.setPackage_name_carrier(pack);
   		        		 dati.setCarrier(listaCar);
   		        		 dati.setDaily_average_carrier(dai);
   		        		 dati.setTotal_average_carrier(tot);
   		        		
   		        		 System.out.println(filename.get(i)+" :");
   		        		 System.out.println(dati.getPackage_name_carrier());
   		        		 System.out.println(dati.getData_carrier());
   		        		 System.out.println(dati.getCarrier());
   		        		 System.out.println(dati.getDaily_average_carrier());
   		        		 System.out.println(dati.getTotal_average_carrier());
   		        		 System.out.println();
   		        		 
   		        		 
       		        }
       		        else if(filename.get(i).contains("country")){
      		        	 dati.setData_country(dat);
   		        		 dati.setPackage_name_country(pack);
   		        		 dati.setCountry(listaCountry);
   		        		 dati.setDaily_average_country(dai);
   		        		 dati.setTotal_average_country(tot);
   		        		
   		        		 System.out.println(filename.get(i)+" :");
   		        		 System.out.println(dati.getPackage_name_country());
   		        		 System.out.println(dati.getData_country());
   		        		 System.out.println(dati.getCountry());
   		        		 System.out.println(dati.getDaily_average_country());
   		        		 System.out.println(dati.getTotal_average_country());
   		        		 System.out.println();
   		        		
       		        }
       		        else if(filename.get(i).contains("device")){
      		        	     dati.setData_device(dat);
   		        		 dati.setPackage_name_device(pack);
   		        		 dati.setDevice(listaDevice);
   		        		 dati.setDaily_average_device(dai);
   		        		 dati.setTotal_average_device(tot);
   		        		
   		        		 System.out.println(filename.get(i)+" :");
   		        		 System.out.println(dati.getPackage_name_device());
   		        		 System.out.println(dati.getData_device());
   		        		 System.out.println(dati.getDevice());
   		        		 System.out.println(dati.getDaily_average_device());
   		        		 System.out.println(dati.getTotal_average_device());
   		        		 System.out.println();
   		        		 
       		        }
       		        else if(filename.get(i).contains("language")){
      		        	     dati.setData_language(dat);
   		        		 dati.setPackage_name_language(pack);
   		        		 dati.setLanguage(listaLanguage);
   		        		 dati.setDaily_average_language(dai);
   		        		 dati.setTotal_average_language(tot);
   		        			
   		        		 System.out.println(filename.get(i)+" :");
   		        		 System.out.println(dati.getPackage_name_language());
   		        		 System.out.println(dati.getData_language());
   		        		 System.out.println(dati.getLanguage());
   		        		 System.out.println(dati.getDaily_average_language());
   		        		 System.out.println(dati.getTotal_average_language());
   		        		 System.out.println();
   		        		 
       		        }
       		        else if(filename.get(i).contains("tablets")){
      		        	 dati.setData_tablet(dat);
   		        		 dati.setPackage_name_tablet(pack);
   		        		 dati.setTablet(listaTab);
   		        		 dati.setDaily_average_tablet(dai);
   		        		 dati.setTotal_average_tablet(tot);
   		        		
   		        		 System.out.println(filename.get(i)+" :");
   		        		 System.out.println(dati.getPackage_name_tablet());
   		        		 System.out.println(dati.getData_tablet());
   		        		 System.out.println(dati.getTablet());
   		        		 System.out.println(dati.getDaily_average_tablet());
   		        		 System.out.println(dati.getTotal_average_tablet());
   		        		 System.out.println();
   		        		 
       		        }
       		        listaFile.clear();
    					
       		    

    				}
    				 
    		        
    		        
    		        
    		     
    		      
    			}
    		}
    		
    		
    		
    	}else if(s.equals("WinStore")){
    		
    		ArrayList<String> filename = new ArrayList<String>();
    		filename.add("src/rating_win/Ratings_average_over_time_app_win.tsv");
    		filename.add("src/rating_win/Ratings_markets_app_win.tsv");
    		filename.add("src/rating_win/Ratings_new_and_revised_app_win.tsv");
    		
    		
    		
    		for(int i = 0; i < filename.size();i++){
    			if(filename.get(i).substring(0).contains(this.nomeApp) == true){
    				
    				String f = filename.get(i);
    				File fi = new File(f);
    				
    				Scanner inputStream = new Scanner(fi);
    				String data = inputStream.nextLine();
    				String[] attr = data.split(",");
    				for(int z = 0; z < attr.length;z++){
    					at.add(attr[z]);
    				}
    				dati.setAttributi(at);
    				
    				while(inputStream.hasNextLine()){
    					data = inputStream.nextLine();
    					String[] values = data.split(",");
    					for(int t = 0; t < values.length;t++){
    						switch(dati.getAttributi().get(t)){
    							case "Name":
    								name_pack = values[t];
    							break;
    							case "Date":
    								date_win.add(values[t]);
    							break;
    							case "Rating":
    								if(primoRating == false){
	    								primoRating = true;
	    								rat.add(values[t]);
	    							}else{
	    								boolean duplicato = false;
	    								for(int c = 0; c < rat.size();c++){
	    									if(rat.get(c).equals(values[t]) ){
	    										duplicato = true;
	    									}
	    								}
	    								if(duplicato == false){
	    									rat.add(values[t]);
	    								}
	    								
	    							}
	    						break;
    							case "Type":
    								if(primoType == false){
	    								primoType = true;
	    								type.add(values[t]);
	    							}else{
	    								boolean duplicato = false;
	    								for(int c = 0; c < type.size();c++){
	    									if(type.get(c).equals(values[t]) ){
	    										duplicato = true;
	    									}
	    								}
	    								if(duplicato == false){
	    									type.add(values[t]);
	    								}
	    								
	    							}
    								tipo = values[t];
    							break;
    							case "Count":
    								if(filename.get(i).contains("average_over_time")){
    									Double b = Double.parseDouble(values[t]);
    									count_average.add(b);
    								}
    								else if(filename.get(i).contains("new_and_revised")){
    									
    										if(tipo.equals("New rating")){
    											Double valor = Double.parseDouble(values[t]);
    											somma_new += valor;
    										}else if(tipo.equals("Revised rating")){
    											Double valor1 = Double.parseDouble(values[t]);
    											somma_revised += valor1;
    										}
    									
    								}
    							break;
    							case "Market":
    								market.add(values[t]);
    							break;
    							case "Average rating":
    								Double av = Double.parseDouble(values[t]);
    								average_rating.add(av);
    							break;
    							case "Number of ratings":
    								Integer nu = Integer.parseInt(values[t]);
    								number_rating.add(nu);
    							break;
    						}
    					}
    				}
 		    	  inputStream.close();
 		    	  
 		    	  if(filename.get(i).contains("average_over_time")){
 		    		  dati.setName(name_pack);
 		    		  dati.setDate_win(date_win);
 		    		  dati.setCount_average(count_average);
 		    		 
 		    		  System.out.println(filename.get(i) + " :");
 		    		  System.out.println(dati.getName());
 		    		  System.out.println(dati.getDate_win());
 		    		  System.out.println(dati.getCount_average());
 		    		  System.out.println();
 		    	  }
 		    	  else if(filename.get(i).contains("new_and_revised")){
 		    		  dati.setRating(rat);
		    		  dati.setType(type);
		    		  dati.setCount_new(somma_new);
		    		  dati.setCount_revised(somma_revised);
		    		  
		    		  System.out.println(filename.get(i) + " :");
		    		  System.out.println(dati.getRating());
		    		  System.out.println(dati.getType());
		    		  System.out.println(dati.getCount_new());
		    		  System.out.println(dati.getCount_revised());
		    		  System.out.println();
 		    	  }
 		    	 else if(filename.get(i).contains("markets")){
		    		  dati.setMarket(market);
		    		  dati.setAverage_rating(average_rating);
		    		  dati.setNumber_rating(number_rating);
		    		  
		    		  System.out.println(filename.get(i) + " :");
		    		  System.out.println(dati.getMarket());
		    		  System.out.println(dati.getAverage_rating());
		    		  System.out.println(dati.getNumber_rating());
		    		  System.out.println();
		    	  }
 		    	  //i = chil.length;
    			  at.clear();
    			  
 		       }
    			
    		}

    	}
		
    	setDati(dati);
		
    	
    }
    /**
     * Funzione per scaricare i dati di un'App
     *
     * @return Il file contente i dati dell'App
     */
    public File scaricamentoDati(){
        
    	return null;
    }
	public ElementAppStore getStore() {
		return store;
	}
	public void setStore(ElementAppStore store) {
		this.store = store;
	}

	public String getNomeApp() {
		return nomeApp;
	}

	public void setNomeApp(String nomeApp) {
		this.nomeApp = nomeApp;
	}

	public Dati getDati() {
		return dati;
	}

	public void setDati(Dati dati) {
		this.dati = dati;
	}

	
}