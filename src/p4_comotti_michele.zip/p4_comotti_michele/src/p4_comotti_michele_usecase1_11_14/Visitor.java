package p4_comotti_michele_usecase1_11_14;
/**
 * Interfaccia del pattern Visitor per implementare il Visitor
 */
public interface Visitor{ 
    /**
     * Funzione visit del Visitor per il GoogleStore
     *
     */
    public void visit(GoogleStore google) ;
    /**
     * Funzione visit del Visitor per il GoogleStore
     *
     */
    public void visit(AppleStore apple);
    /**
     * Funzione visit del Visitor per il GoogleStore
     *
     */
    public void visit(WinStore win);
}