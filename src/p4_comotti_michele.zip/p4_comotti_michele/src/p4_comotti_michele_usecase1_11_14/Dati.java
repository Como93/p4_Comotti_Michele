package p4_comotti_michele_usecase1_11_14;

import java.util.ArrayList;

/**
 * Classe per definire l'oggetto Dati
 */
public class Dati{
	
	/** Constanti per indicare la provenienza dell'App (cioè da quale AppStore è stata salvata
	 * @param GOOGLE_PLAY_STORE 1
	 * @param APPLE_STORE 2
	 * @param WINDOWS_STORE 3 */
	private final static int GOOGLE_PLAY_STORE = 1;
	private final static int APPLE_STORE = 2;
	private final static int WINDOWS_STORE = 3;
	
    /** Attributi */
    private int provenienza;
    private ArrayList<String> attributi; // ArrayList di attributi che vengono letti all'interno del file
    //Google
    
    // App Version 
    private ArrayList<String> data_app_version;
    private String package_name_app_version;
    private ArrayList<String> app_version;
    private ArrayList<Double> daily_average_app_version;
	private ArrayList<Double> total_average_app_version;
	// Carrier
	private ArrayList<String> data_carrier;
	private String package_name_carrier;
	private ArrayList<String> carrier;
	private ArrayList<Double> daily_average_carrier;
    private ArrayList<Double> total_average_carrier;
    // Country
    private ArrayList<String> data_country;
	private String package_name_country;
	private ArrayList<String> country;
	private ArrayList<Double> daily_average_country;
    private ArrayList<Double> total_average_country;
    // Device
    private ArrayList<String> data_device;
	private String package_name_device;
	private ArrayList<String> device;
	private ArrayList<Double> daily_average_device;
    private ArrayList<Double> total_average_device;
    // Language
    private ArrayList<String> data_language;
   	private String package_name_language;
   	private ArrayList<String> language;
   	private ArrayList<Double> daily_average_language;
    private ArrayList<Double> total_average_language;
	// Os Version
    private ArrayList<String> data_os_version;
   	private String package_name_os_version;
   	private ArrayList<String> os_version;
   	private ArrayList<Double> daily_average_os_version;
    private ArrayList<Double> total_average_os_version;
    // Tablet
    private ArrayList<String> data_tablet;
   	private String package_name_tablet;
   	private ArrayList<String> tablet;
   	private ArrayList<Double> daily_average_tablet;
    private ArrayList<Double> total_average_tablet;
    // Overview
    private ArrayList<String> data_overview;
   	private String package_name_overview;
    private ArrayList<Double> daily_average_overview;
    private ArrayList<Double> total_average_overview;
    
    // Windows Store
    
    // Rating new and revised
    private ArrayList<String> rating;
    private ArrayList<String> type;
    private double count_new;
    private double count_revised;
    // Rating average over time
    private String name;
    private ArrayList<String> date_win;
    private ArrayList<Double> count_average;
    // Rating market
    private ArrayList<String> market;
    private ArrayList<Double> average_rating;
    private ArrayList<Integer> number_rating;
    
    //PARTE DI INSTALL(NON SVILUPPATA NELLA NORMALIZZAZIONE DA ME)
    
  //GOOGLEstore
  	//Overview
  	private ArrayList<String> overview_data_install;
  	private ArrayList<Integer> overview_dailyUserInstalls;	//Anche WinStore (install)

  	private ArrayList<Integer> overview_totUserInstalls;	
  	private ArrayList<Integer> overview_dailyUserUninstalls;
  	private ArrayList<Integer> overview_activeDeviceInstalls;
  	
  	//Aggregazione per carrier
  	private ArrayList<String> carrier_data_install;
  	private ArrayList<Integer> carrier_totUserInstalls;
  	private ArrayList<Integer> carrier_dailyUserInstalls;
  	private ArrayList<Integer> carrier_dailyUserUninstalls;
  	private ArrayList<Integer> carrier_activeDeviceInstalls;

  	//Aggregazione per paese
  	private ArrayList<String> country_data_install;
  	private ArrayList<Integer> country_dailyUserInstalls;	//Anche WinStore (install_markets)

  	private ArrayList<Integer> country_totUserInstalls;
  	private ArrayList<Integer> country_dailyUserUninstalls;
  	private ArrayList<Integer> country_activeDeviceInstalls;
  	
  	//Aggregazione per device
  	private ArrayList<String> device_data_install;
  	private ArrayList<Integer> device_totUserInstalls;
  	private ArrayList<Integer> device_dailyUserInstalls;
  	private ArrayList<Integer> device_dailyUserUninstalls;
  	private ArrayList<Integer> device_activeDeviceInstalls;
  	
  	//Aggregazione per lingua
  	private ArrayList<String> lang_data_install;
  	private ArrayList<Integer> lang_totUserInstalls;
  	private ArrayList<Integer> lang_dailyUserInstalls;
  	private ArrayList<Integer> lang_dailyUserUninstalls;
  	private ArrayList<Integer> lang_activeDeviceInstalls;
  	
  	//Aggregazione per versione OS
  	private ArrayList<String> osVersion_data_install;
  	private ArrayList<Integer> osVersion_dailyUserInstalls;	//Anche WinStore (acquisition_os)

  	private ArrayList<Integer> osVersion_totUserInstalls;
  	private ArrayList<Integer> osVersion_dailyUserUninstalls;
  	private ArrayList<Integer> osVersion_activeDeviceInstalls;
  	
  	//Aggregazione per tablet
  	private ArrayList<String> tablet_data_install;
  	private ArrayList<Integer> tablet_totUserInstalls;
  	private ArrayList<Integer> tablet_dailyUserInstalls;
  	private ArrayList<Integer> tablet_dailyUserUninstalls;
  	private ArrayList<Integer> tablet_activeDeviceInstalls;
  	
  	
  	//WINDOWSstore
  	private ArrayList<String> failure_data;
  	private ArrayList<Integer> failure_count;	//Da failure
    
    
	
	
	public ArrayList<String> getAttributi() {
		return attributi;
	}

	public void setAttributi(ArrayList<String> attributi) {
		this.attributi = attributi;
	}

	public ArrayList<String> getData_app_version() {
		return data_app_version;
	}

	public void setData_app_version(ArrayList<String> data_app_version) {
		this.data_app_version = data_app_version;
	}

	public String getPackage_name_app_version() {
		return package_name_app_version;
	}

	public void setPackage_name_app_version(String package_name_app_version) {
		this.package_name_app_version = package_name_app_version;
	}

	public ArrayList<String> getApp_version() {
		return app_version;
	}

	public void setApp_version(ArrayList<String> app_version) {
		this.app_version = app_version;
	}

	public ArrayList<Double> getDaily_average_app_version() {
		return daily_average_app_version;
	}

	public void setDaily_average_app_version(ArrayList<Double> daily_average_app_version) {
		this.daily_average_app_version = daily_average_app_version;
	}

	public ArrayList<Double> getTotal_average_app_version() {
		return total_average_app_version;
	}

	public void setTotal_average_app_version(ArrayList<Double> total_average_app_version) {
		this.total_average_app_version = total_average_app_version;
	}

	public ArrayList<String> getData_carrier() {
		return data_carrier;
	}

	public void setData_carrier(ArrayList<String> data_carrier) {
		this.data_carrier = data_carrier;
	}

	public String getPackage_name_carrier() {
		return package_name_carrier;
	}

	public void setPackage_name_carrier(String package_name_carrier) {
		this.package_name_carrier = package_name_carrier;
	}

	public ArrayList<String> getCarrier() {
		return carrier;
	}

	public void setCarrier(ArrayList<String> carrier) {
		this.carrier = carrier;
	}

	public ArrayList<Double> getDaily_average_carrier() {
		return daily_average_carrier;
	}

	public void setDaily_average_carrier(ArrayList<Double> daily_average_carrier) {
		this.daily_average_carrier = daily_average_carrier;
	}

	public ArrayList<Double> getTotal_average_carrier() {
		return total_average_carrier;
	}

	public void setTotal_average_carrier(ArrayList<Double> total_average_carrier) {
		this.total_average_carrier = total_average_carrier;
	}

	public ArrayList<String> getData_country() {
		return data_country;
	}

	public void setData_country(ArrayList<String> data_country) {
		this.data_country = data_country;
	}

	public String getPackage_name_country() {
		return package_name_country;
	}

	public void setPackage_name_country(String package_name_country) {
		this.package_name_country = package_name_country;
	}

	public ArrayList<String> getCountry() {
		return country;
	}

	public void setCountry(ArrayList<String> country) {
		this.country = country;
	}

	public ArrayList<Double> getDaily_average_country() {
		return daily_average_country;
	}

	public void setDaily_average_country(ArrayList<Double> daily_average_country) {
		this.daily_average_country = daily_average_country;
	}

	public ArrayList<Double> getTotal_average_country() {
		return total_average_country;
	}

	public void setTotal_average_country(ArrayList<Double> total_average_country) {
		this.total_average_country = total_average_country;
	}

	public ArrayList<String> getData_device() {
		return data_device;
	}

	public void setData_device(ArrayList<String> data_device) {
		this.data_device = data_device;
	}

	public String getPackage_name_device() {
		return package_name_device;
	}

	public void setPackage_name_device(String package_name_device) {
		this.package_name_device = package_name_device;
	}

	public ArrayList<String> getDevice() {
		return device;
	}

	public void setDevice(ArrayList<String> device) {
		this.device = device;
	}

	public ArrayList<Double> getDaily_average_device() {
		return daily_average_device;
	}

	public void setDaily_average_device(ArrayList<Double> daily_average_device) {
		this.daily_average_device = daily_average_device;
	}

	public ArrayList<Double> getTotal_average_device() {
		return total_average_device;
	}

	public void setTotal_average_device(ArrayList<Double> total_average_device) {
		this.total_average_device = total_average_device;
	}

	public ArrayList<String> getData_language() {
		return data_language;
	}

	public void setData_language(ArrayList<String> data_language) {
		this.data_language = data_language;
	}

	public String getPackage_name_language() {
		return package_name_language;
	}

	public void setPackage_name_language(String package_name_language) {
		this.package_name_language = package_name_language;
	}

	public ArrayList<String> getLanguage() {
		return language;
	}

	public void setLanguage(ArrayList<String> language) {
		this.language = language;
	}

	public ArrayList<Double> getDaily_average_language() {
		return daily_average_language;
	}

	public void setDaily_average_language(ArrayList<Double> daily_average_language) {
		this.daily_average_language = daily_average_language;
	}

	public ArrayList<Double> getTotal_average_language() {
		return total_average_language;
	}

	public void setTotal_average_language(ArrayList<Double> total_average_language) {
		this.total_average_language = total_average_language;
	}

	public ArrayList<String> getData_os_version() {
		return data_os_version;
	}

	public void setData_os_version(ArrayList<String> data_os_version) {
		this.data_os_version = data_os_version;
	}

	public String getPackage_name_os_version() {
		return package_name_os_version;
	}

	public void setPackage_name_os_version(String package_name_os_version) {
		this.package_name_os_version = package_name_os_version;
	}

	public ArrayList<String> getOs_version() {
		return os_version;
	}

	public void setOs_version(ArrayList<String> os_version) {
		this.os_version = os_version;
	}

	public ArrayList<Double> getDaily_average_os_version() {
		return daily_average_os_version;
	}

	public void setDaily_average_os_version(ArrayList<Double> daily_average_os_version) {
		this.daily_average_os_version = daily_average_os_version;
	}

	public ArrayList<Double> getTotal_average_os_version() {
		return total_average_os_version;
	}

	public void setTotal_average_os_version(ArrayList<Double> total_average_os_version) {
		this.total_average_os_version = total_average_os_version;
	}

	public ArrayList<String> getData_tablet() {
		return data_tablet;
	}

	public void setData_tablet(ArrayList<String> data_tablet) {
		this.data_tablet = data_tablet;
	}

	public String getPackage_name_tablet() {
		return package_name_tablet;
	}

	public void setPackage_name_tablet(String package_name_tablet) {
		this.package_name_tablet = package_name_tablet;
	}

	public ArrayList<String> getTablet() {
		return tablet;
	}

	public void setTablet(ArrayList<String> tablet) {
		this.tablet = tablet;
	}

	public ArrayList<Double> getDaily_average_tablet() {
		return daily_average_tablet;
	}

	public void setDaily_average_tablet(ArrayList<Double> daily_average_tablet) {
		this.daily_average_tablet = daily_average_tablet;
	}

	public ArrayList<Double> getTotal_average_tablet() {
		return total_average_tablet;
	}

	public void setTotal_average_tablet(ArrayList<Double> total_average_tablet) {
		this.total_average_tablet = total_average_tablet;
	}

	public ArrayList<String> getData_overview() {
		return data_overview;
	}

	public void setData_overview(ArrayList<String> data_overview) {
		this.data_overview = data_overview;
	}

	public String getPackage_name_overview() {
		return package_name_overview;
	}

	public void setPackage_name_overview(String package_name_overview) {
		this.package_name_overview = package_name_overview;
	}

	public ArrayList<Double> getDaily_average_overview() {
		return daily_average_overview;
	}

	public void setDaily_average_overview(ArrayList<Double> daily_average_overview) {
		this.daily_average_overview = daily_average_overview;
	}

	public ArrayList<Double> getTotal_average_overview() {
		return total_average_overview;
	}

	public void setTotal_average_overview(ArrayList<Double> total_average_overview) {
		this.total_average_overview = total_average_overview;
	}

	public ArrayList<String> getRating() {
		return rating;
	}

	public void setRating(ArrayList<String> rating) {
		this.rating = rating;
	}

	public ArrayList<String> getType() {
		return type;
	}

	public void setType(ArrayList<String> type) {
		this.type = type;
	}

	public double getCount_new() {
		return count_new;
	}

	public void setCount_new(double count_new) {
		this.count_new = count_new;
	}

	public double getCount_revised() {
		return count_revised;
	}

	public void setCount_revised(double count_revised) {
		this.count_revised = count_revised;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<String> getDate_win() {
		return date_win;
	}

	public void setDate_win(ArrayList<String> date_win) {
		this.date_win = date_win;
	}

	public ArrayList<Double> getCount_average() {
		return count_average;
	}

	public void setCount_average(ArrayList<Double> count_average) {
		this.count_average = count_average;
	}

	public ArrayList<String> getMarket() {
		return market;
	}

	public void setMarket(ArrayList<String> market) {
		this.market = market;
	}

	public ArrayList<Double> getAverage_rating() {
		return average_rating;
	}

	public void setAverage_rating(ArrayList<Double> average_rating) {
		this.average_rating = average_rating;
	}

	public ArrayList<Integer> getNumber_rating() {
		return number_rating;
	}

	public void setNumber_rating(ArrayList<Integer> number_rating) {
		this.number_rating = number_rating;
	}

	
	
	public int getProvenienza() {
		return provenienza;
	}

	public void setProvenienza(int provenienza) {
		this.provenienza = provenienza;
	}

	
    
}