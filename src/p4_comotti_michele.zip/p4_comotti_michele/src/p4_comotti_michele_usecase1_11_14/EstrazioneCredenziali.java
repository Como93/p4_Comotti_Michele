package p4_comotti_michele_usecase1_11_14;
import java.rmi.Remote;
import java.rmi.RemoteException;
//Interfaccia con i metodi per settare ed estrarre le credenziali
public interface EstrazioneCredenziali extends Remote{
	public String getEstrazioneUser(String store) throws RemoteException;
	public String getEstrazionePass(String store) throws RemoteException;
	public void setEstrazioneUser(String store,String user) throws RemoteException;
	public void setEstrazionePass(String store,String pass) throws RemoteException;
}
