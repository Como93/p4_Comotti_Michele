package p4_comotti_michele_usecase1_11_14;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class EstrazioneCredenzialiImpl extends UnicastRemoteObject implements EstrazioneCredenziali {

	/**
	 * 
	 */
	//Implementazione dei metodi per settare ed estrarre le credenziali
	private static final long serialVersionUID = 1L;
	private String userGoogle;
	private String userWin;
	private String userApple;
	private String passGoogle;
	private String passWin;
	private String passApple;

	public EstrazioneCredenzialiImpl() throws RemoteException {
		
		// TODO Auto-generated constructor stub
	}

	

	@Override
	public String getEstrazioneUser(String store) throws RemoteException {
		// TODO Auto-generated method stub
		String utente = null;
		if(store.equals("GoogleStore")){
			utente =  userGoogle;
		}else if(store.equals("WinStore")){
			utente = userWin;
		}else if(store.equals("AppleStore")){
			utente = userApple;
		}
		return utente;
	}

	@Override
	public String getEstrazionePass(String store) throws RemoteException {
		// TODO Auto-generated method stub
		String password = null;
		if(store.equals("GoogleStore")){
			password = passGoogle;
		}else if(store.equals("WinStore")){
			password = passWin;
		}else if(store.equals("AppleStore")){
			password = passApple;
		}
		return password;
	}

	@Override
	public void setEstrazioneUser(String store, String user) throws RemoteException {
		// TODO Auto-generated method stub
		if(store.equals("GoogleStore")){
			this.userGoogle = user;
		}else if(store.equals("WinStore")){
			this.userWin = user;
		}else if(store.equals("AppleStore")){
			this.userApple = user;
		}
	}

	@Override
	public void setEstrazionePass(String store, String pass) throws RemoteException {
		// TODO Auto-generated method stub
		if(store.equals("GoogleStore")){
			this.passGoogle = pass;
		}else if(store.equals("WinStore")){
			this.passWin = pass;
		}else if(store.equals("AppleStore")){
			this.passApple = pass;
		}
	}

}
