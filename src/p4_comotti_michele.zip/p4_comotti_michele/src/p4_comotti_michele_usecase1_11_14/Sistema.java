package p4_comotti_michele_usecase1_11_14;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Scanner;
/**
 * Classe per la definizione del Sistema
 */
public class Sistema{ 
    /** Associazioni */
    private ArrayList<ElementAppStore> appStores;
    private ArrayList<App> apps;
    private ArrayList<Gruppo> gruppi; 
    
    
    public Sistema(ArrayList<ElementAppStore> appStores,ArrayList<App> apps) {
		this.apps = apps;
		this.appStores = appStores;
	}
	/**
     * Funzione per aggiungere le credenziali di un'AppStore tra quelli supportati
     *
     */
    /*AGGIUNTA CREDENZIALI : metodo lanciato da sistema che permette l'aggiunta delle credenziali dei 
     * vari app store, e quindi permette di collegarsi con il proprio username e password.
     * L'utente deve avere un account per poter svolgere questa operazione.
     */
    
    public void aggiuntaCredenziali(ElementAppStore s) {
    	
    	try{
    		Credenziali c_server = new Credenziali();
    		String store = s.toString().substring(s.toString().indexOf(".")+1, s.toString().indexOf("@"));
    		EstrazioneCredenziali estrazione = null;
        	
        	estrazione = (EstrazioneCredenziali)Naming.lookup("rmi://localhost:5252/estrazione");
        	
    		
        	String server_user = estrazione.getEstrazioneUser(store);
        	
        	String server_pass = estrazione.getEstrazionePass(store);
        	
        	c_server.setUsername(server_user);
        	c_server.setPassword(server_pass);
        	
            s.accept(new Accesso(c_server));
    	}catch(MalformedURLException e){
    		e.printStackTrace();
    	}catch(RemoteException e){
    		e.printStackTrace();
    	}catch(NotBoundException e){
    		e.printStackTrace();
    	}
		
    	
        
    }
    /**
     * Funzione per inserire App nel Sistema
     *
     */
    public void inserimentoApp(){
         
    }
    /**
     * Funzione per cancellare App dal Sistema
     *
     * 
     */
    public void cancellazioneApp(){
 
    }
    /**
     * Funzione per creare un nuovo Gruppo
     *
     */
    public void creazioneGruppo(){
 
    }
    /**
     * Funzione per cancellare un Gruppo
     *
     */
    public void cancellazioneGruppo(){
 
    }
    /**
     * Funzione per cancellare le credenziali di un'AppStore 
     *
     * @return true se è andata a buon fine, false se non è andata a buon fine
     */
    public boolean cancellazioneCredenziali(){
 
    	return false;
    }
    /**
     * Funzione per modificare le credenziali di un'AppStore
     *
     *  
     */
    /*MODIFICA CREDENZIALI : l'utente ha la possibilità di modificare le credenziali dei vari app store
     * L'utente deve aver registrato le credenziali nei vari element app store per poter fare questa operazione
     */
    public void modificaCredenziali(GoogleStore g,WinStore w,AppleStore a,ElementAppStore st){
		
    	
    	try {
    		
    		String store = st.toString().substring(st.toString().indexOf(".")+1, st.toString().indexOf("@"));
        	EstrazioneCredenziali aggiorna = null;
			aggiorna = (EstrazioneCredenziali)Naming.lookup("rmi://localhost:5252/estrazione");
			Scanner scanner = new Scanner(System.in);
			String u = null;
			String p = null;
			boolean response = false;
			
			
			if(store.equals("GoogleStore")){
	    		if(g.getCredenzialiGoogle() == null){
	    			System.out.println("Non puoi modificare queste credenziali! Aggiungile nel sistema! ");
	    		}else{
	    			while(response == false){
	    				System.out.println("Reinserisci nome utente");
		    			u = scanner.nextLine();
		    			System.out.println("Reinserisci password");
		    			p = scanner.nextLine();
		    			System.out.println("Confermi le modifiche? 1 per si 0 per no");
		    			int scelta = scanner.nextInt();
		    			
		    			switch(scelta){
		    				case 0:
		    					scanner = new Scanner(System.in);
		    				break;
		    				case 1:
		    					aggiorna.setEstrazioneUser(store, u);
		    					aggiorna.setEstrazionePass(store, p);
		    					aggiuntaCredenziali(st);
		    					response = true;
		    				break;
		    				
		    			}
	    			}
	    			
	    			
	    		}
	    	}else if(store.equals("WinStore")){
	    		if(w.getCredenzialiWin() == null){
	    			System.out.println("Non puoi modificare queste credenziali! Aggiungile nel sistema! ");
	    		}else{
	    			while(response == false){
	    				System.out.println("Reinserisci nome utente");
		    			u = scanner.nextLine();
		    			System.out.println("Reinserisci password");
		    			p = scanner.nextLine();
		    			System.out.println("Confermi le modifiche? 1 per si 0 per no");
		    			int scelta = scanner.nextInt();
		    			
		    			switch(scelta){
		    				case 0:
		    					scanner = new Scanner(System.in);
		    				break;
		    				case 1:
		    					aggiorna.setEstrazioneUser(store, u);
		    					aggiorna.setEstrazionePass(store, p);
		    					aggiuntaCredenziali(st);
		    					response = true;
		    				break;
		    			}
	    			}
	    		}
	    	}else if(store.equals("AppleStore")){
	    		if(a.getCredenzialiApple() == null){
	    			System.out.println("Non puoi modificare queste credenziali! Aggiungile nel sistema! ");
	    		}else{
	    			while(response == false){
	    				System.out.println("Reinserisci nome utente");
		    			u = scanner.nextLine();
		    			System.out.println("Reinserisci password");
		    			p = scanner.nextLine();
		    			System.out.println("Confermi le modifiche? 1 per si 0 per no");
		    			int scelta = scanner.nextInt();
		    			
		    			switch(scelta){
		    				case 0:
		    					scanner = new Scanner(System.in);
		    				break;
		    				case 1:
		    					aggiorna.setEstrazioneUser(store, u);
		    					aggiorna.setEstrazionePass(store, p);
		    					aggiuntaCredenziali(st);
		    					response = true;
		    				break;
		    			}
	    			}
	    		}
	    	}
		} catch (MalformedURLException | RemoteException | NotBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    	
    }
    /**
     * Funzione per aggiungere un'App ad un Gruppo
     *
     */
    public void aggiuntaAppGruppo(){
        
    }
    /**
     * Funzione per cancellare un'App da un Gruppo
     *
     */
    public void cancellazioneAppGruppo(){
    	
    }
	public ArrayList<App> getApps() {
		return apps;
	}
	public void setApps(ArrayList<App> apps) {
		this.apps = apps;
	}
	public ArrayList<ElementAppStore> getAppStores() {
		return appStores;
	}
	public void setAppStores(ArrayList<ElementAppStore> appStores) {
		this.appStores = appStores;
	}
	
    
}