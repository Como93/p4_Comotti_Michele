package p4_comotti_michele_usecase1_11_14;

import java.io.IOException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws IOException, NotBoundException {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		
		GoogleStore google = new GoogleStore();
		WinStore windows = new WinStore();
		AppleStore apple = new AppleStore();
		
		ArrayList<ElementAppStore> store = new ArrayList<ElementAppStore>();
		store.add(google);
		store.add(windows);
		store.add(apple);
		
		String sGoogle = store.get(0).toString().substring(store.get(0).toString().indexOf(".")+1, store.get(0).toString().indexOf("@"));
		String sWin = store.get(1).toString().substring(store.get(0).toString().indexOf(".")+1, store.get(1).toString().indexOf("@"));
		String sApple = store.get(2).toString().substring(store.get(0).toString().indexOf(".")+1, store.get(2).toString().indexOf("@"));

		EstrazioneCredenziali estrazione = null;
    	
    	estrazione = (EstrazioneCredenziali)Naming.lookup("rmi://localhost:5252/estrazione");
		
		estrazione.setEstrazioneUser(sGoogle, "como9307@gmail.com");
		estrazione.setEstrazionePass(sGoogle, "michele");
		estrazione.setEstrazioneUser(sWin, "djmitchbello@hotmail.it");
		estrazione.setEstrazionePass(sWin, "comotti");
		estrazione.setEstrazioneUser(sApple, "como9307@icloud.com");
		estrazione.setEstrazionePass(sApple, "cloud");
		
		App letfreex = new App("letfreex",google);
		App app_win = new App("app_win",windows);
		
		ArrayList<App> a = new ArrayList<App>();
		a.add(letfreex);
		a.add(app_win);
		
		Sistema sistema = new Sistema(store,a);
		
		System.out.println("Scegli quale operazioni vuoi effettuare! Premi");
		System.out.println("1 - Normalizzazione");
		System.out.println("2 - Aggiunta Credenziali");
		if(google.getCredenzialiGoogle() != null || windows.getCredenzialiWin() != null || apple.getCredenzialiApple() != null){
			System.out.println("3 - Modifica Credenziali");
		}
		
		System.out.println("0 - Esci");
		
		
		int premi = input.nextInt();
		
		
		while(premi != 0) {
			switch(premi){
				case 1 :
					System.out.println("Normalizziamo i dati! Scegli quale app normalizzare i dati");
					System.out.println("Premi: ");
					for(int i = 0; i < sistema.getApps().size();i++){
						System.out.println(i +" - "+ sistema.getApps().get(i).getNomeApp());
					}
					
					int scelta = input.nextInt();
					
					sistema.getApps().get(scelta).visualizzazioneDati();
					
				break;
				case 2 :
					System.out.println("Colleghiamoci ad un app store! Scegli l'app store");
					System.out.println("Premi: ");
					
					for(int i = 0; i < sistema.getAppStores().size();i++){
						System.out.println(i +" - "+ sistema.getAppStores().get(i).toString().substring(sistema.getAppStores().get(i).toString().indexOf(".")+1, sistema.getAppStores().get(i).toString().indexOf("@")));
					}
					 
					int scelta1 = input.nextInt();
					
					
					
				 sistema.aggiuntaCredenziali(sistema.getAppStores().get(scelta1));
				
				break;
				
				case 3 :
					/*Suppongo di aver già modificato le credenziali nel mio app store ma non nel mio sistema*/
					
					if(google.getCredenzialiGoogle() != null || windows.getCredenzialiWin() != null || apple.getCredenzialiApple() != null){

						System.out.println("Modifichiamo credenziali App Store");
						System.out.println("Premi: ");
						
						for(int i = 0; i < sistema.getAppStores().size();i++){
							System.out.println(i +" - "+ sistema.getAppStores().get(i).toString().substring(sistema.getAppStores().get(i).toString().indexOf(".")+1, sistema.getAppStores().get(i).toString().indexOf("@")));
						}
						
						int scelta11 = input.nextInt();
						
						
						sistema.modificaCredenziali(google,windows,apple,sistema.getAppStores().get(scelta11));
					} else {
						System.out.println("Devi aggiungere nel sistema delle credenziali di almeno un tuo account App Store");
					}
				break;
			}
			System.out.println("Vuoi continuare? Premi 0 per uscire");
			System.out.println("1 - Normalizzazione");
			System.out.println("2 - Aggiunta Credenziali");
			if(google.getCredenzialiGoogle() != null || windows.getCredenzialiWin() != null || apple.getCredenzialiApple() != null){
				System.out.println("3 - Modifica Credenziali");
			}
			System.out.println("0 - Esci");
			
			premi = input.nextInt();
			
			
		}
		
		
		
		
	}

}
