package p4_comotti_michele_usecase1_11_14;

import java.io.File;
import java.util.ArrayList;
/**
 * Classe per la definizione di Gruppo
 */
public class Gruppo{
    /** Attributi */
    private int id;
    private String nomeGruppo; 
    /** Associations */
    private Dati datiAggregati;
    private ArrayList<App> apps; 
    /**
     * Funzione per la visualizzazione dei dati di un Gruppo
     *
     */
    public void visualizzazioneDati(){

    }
    /**
     * Funzione per l'estrazione dei dati di un Gruppo
     *
     * @return true se è andata a buon fine, false se non è andata a buon fine
     */
    public boolean estrazioneDatiGruppo(){
    	
        return false; 
    }
    /**
     * Funzione per l'aggregazione dei dati delle App contenute nel Gruppo
     *
     */
    public void aggregazioneDati(){
 
    }
    /**
     * Funzione per scaricare i dati di un Gruppo
     *
     * @return Il file contente i dati dell'App
     */
    public File scaricamentoDati(){

    	return null;
    }
}